#Algoritmo que calcule el perimetro de un rectangulo
a=int(input("Digite el 1er lado: "))
b=int(input("Digite el 2do lado: "))
c=int(input("Digite el 3er lado: "))
d=int(input("Digite el 4to lado: "))
p=a+b+c+d
print("El perimetro del rectángulo es: ",p)