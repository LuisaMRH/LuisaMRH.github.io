#Algoritmo que convierta de dolares a pesos colombianos
dol=int(input("Digite el número en dolares "))
c=dol*4.626
print("La conversion de sus dolares a pesos colombianos es $",c)