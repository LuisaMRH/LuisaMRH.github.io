#Algoritmo que sume 2 números enteros
a=5
b=8
c=a+b
print("La suma es: ",c)