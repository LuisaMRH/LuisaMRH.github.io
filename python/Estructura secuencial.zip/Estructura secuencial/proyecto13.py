#Algoritmo que calcule el prestamo y total
p=int(input("Digite el valor del prestamo: "))
i=p*0.17
m=(p+i)/12
print("El interés anual del prestamo es $",i, "y el valor que se debe pagar mensualmente es $",m)