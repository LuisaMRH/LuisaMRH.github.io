#Algoritmo que convierta de grados Fahrenheit a grados Celsius 
f=float(input("Digite el número de grados Fahrenheit: "))
c=(f-32)*5/9
print("El numero de grados fahrenheit en grados Celsius: ",c)

