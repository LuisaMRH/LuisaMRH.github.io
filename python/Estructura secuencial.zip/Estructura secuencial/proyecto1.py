#Algoritmo que imprima un hola mundo
print("Holi mundo!")