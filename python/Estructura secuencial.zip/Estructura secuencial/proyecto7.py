#Calculadora simple
n1=int(input("Digite el 1er número "))
n2=int(input("Digite el 2do número "))

c=n1+n2
print("La suma es: ",c)
c=n1-n2
print("La resta es: ",c)
c=n1*n2
print("La multiplicación es: ",c)
c=n1/n2
print("La división es: ",c)

