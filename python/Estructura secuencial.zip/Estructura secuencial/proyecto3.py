"""
Creado por. Luisa Ramos
Algoritmo que sume 2 números que el usuario ingrese
"""
a=int(input("Digite el primer número: "))
b=int(input("Digite el segundo número: "))
c=a+b
print("La suma de ",a," + ",b," = ",c )