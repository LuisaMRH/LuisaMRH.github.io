#Algoritmo que calcule el area de un rectángulo
a=int(input("Digite la base en cm: "))
b=int(input("Digite la atura en cm: "))
area=a*b
print("El retángulo que tiene como base ",a,"cm y altura ",b,"cm tiene un area de: ", area)