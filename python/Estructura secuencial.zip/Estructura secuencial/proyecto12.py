#Algoritmo que calcule el 15% de descuento  y el total
c=int(input("Digite el valor de la compra: "))
d=c*0.15
t=c-d
print("El descuento de su compra es $",d, "y el total es $",t)
