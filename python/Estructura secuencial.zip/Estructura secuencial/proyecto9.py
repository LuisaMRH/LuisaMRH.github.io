#Algoritmo que calcule el doble y triple de un número
n=int(input("Digite un numero: "))
d=n*2
t=n*3
print("El doble del número es ",d, " y el triple del número es ",t)