#Algoritmo que calcule el area de un circulo
r=int(input("Digite el radio del circulo "))
c=r*r
a=c*3.1416
print("El area del circulo es: ",a)