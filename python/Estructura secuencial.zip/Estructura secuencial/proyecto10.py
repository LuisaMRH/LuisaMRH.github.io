#Algoritmo que convierta en de minutos a horas
m=int(input("Digite el número en minutos: "))
h=m/60
print("En horas es igual a ",h)