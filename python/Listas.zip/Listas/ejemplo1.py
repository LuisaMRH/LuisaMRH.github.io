#for: recorrer un lista
fruits=["apple", "banana", "cherry"]
for x in fruits:
  print(x)

#Array vector: añadir un vector
#Para añadir un elemento a la lista
print("Marca de carros:")
cars=["ford"]
cars.append("Onda")
for x in cars:
  print(x)

#Tamaño de la lista
longitud=len(cars)
print("El tamaño o longitud es: ", longitud)

#Array vector: Eliminar un elemento
#Primera forma, por posición
cars=["Ford", "Volvo", "BMW"]
cars.pop(1)
print(cars)
#Segunda forma, por elemento
cars=["Ford", "Volvo", "BMW"]
cars.remove("Volvo")
print(cars)