#Listas de plantas medicinales con 9 posiciones
p=["Valeriana", "Manzanilla", "Aloe Vera", "Eucalipto", "Jengibre", "Tomillo", "Diente de león", "Orégano", "Amapola"]
#Añadir elemento a la lista
p.append("Marihuna")
#Eliminar un elemento
p.remove("Jengibre")
#Recorrido que hace la lista
print("~PLANTAS MEDICINALES QUE TE PUEDEN AYUDAR:~")
print("     ")
for i in p:
    print(i, end=", ")
#Definir tamaño de la lista
longitud=len(p)
print("El tamaño es: ", longitud)