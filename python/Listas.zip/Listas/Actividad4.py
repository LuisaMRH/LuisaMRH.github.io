#Listas de colores con 8 posiciones
color=["Amarillo", "Azul", "Rojo", "Verde", "Morado", "Naranja", "Rosado", "Celeste"]
#Añadir elemento a la lista
color.append("Gris")
#Eliminar un elemento
color.remove("Naranja")
#Recorrido que hace la lista
print("~Lista de colores:~")
print("     ")
for i in color:
    print(i, end=" ,")
#Definir tamaño de la lista
longitud=len(color)
print("El tamaño es: ", longitud)