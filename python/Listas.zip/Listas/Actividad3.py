#Listas de lenguajes de Programación con 5 posiciones

lp=["Python", "JavaScript", "C++", "PHP", "Go", "Java"]
#Añadir elemento a la lista
lp.append("C#")
#Eliminar un elemento
lp.pop(3)
#Recorrido que hace la lista
print("~Lenguajes de programación que puedes aprender:~")
print("     ")
for i in lp:
    print("-",i)
#Definir tamaño de la lista
longitud=len(lp)
print("El tamaño es: ", longitud)