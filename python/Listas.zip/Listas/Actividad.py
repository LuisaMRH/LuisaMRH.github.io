#Listas de libros con 7 posiciones
libros=["La culpa es de la vaca", "Antes de diciembre", "Después de diciembre", "Tres meses", "Culpa mia", "Culpa tuya", "Culpa nuestra"]
#Añadir elemento a la lista
libros.append("La Odisea")
#Eliminar un elemento
libros.pop(0)
#Recorrido que hace la lista
print("~Los libros que me gustan son:~")
print("     ")
for i in libros:
    print("-",i)
#Definir tamaño de la lista
longitud=len(libros)
print("El tamaño es: ", longitud)