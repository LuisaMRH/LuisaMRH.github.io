"""Evaluar la edad ingresada 
0>= & <2, Eres un baby
12>= & <18, Eres un niñ@
18>= & <40, Eres un adolescente
40>= & <60, Eres un adulto joven
60>=, Eres un adulto mayor"""
edad=int(input("Digite su edad: "))

if edad>=0 and edad<2:
    print("Eres un baby")
elif edad>=2 and edad<12:
    print("Eres un niñ@")
elif edad>=12 and edad<18:
    print("Eres un adolescente")
elif edad>=18 and edad<40:
    print("Eres un adulto joven")
elif edad>=40 and edad<60:
    print("Eres un adulto maduro")
elif edad>=60:
    print("Eres un adulto mayor")
else:
    print("Esto no es una edad... Por favor ingrese un número")

