#App que al ingresar el valor de compra 
#Si el valor de la compra es mayor a $100.000
#Entonces calcule el descuento(7%) y total de la compra

compra=float(input("Digite el valor de la compra: "))

if compra>100000:
    descuento=compra*0.07
    total=compra-descuento
    print("Subtotal: ",compra)
    print("Descuento: ",descuento)
    print("Total de compra: ",total)
else:
    descuento=compra*0.0
    total=compra-descuento
    print("Subtotal: ",compra)
    print("Descuento: ",descuento)
    print("Total de compra: ",total)