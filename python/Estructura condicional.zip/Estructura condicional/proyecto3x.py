#App que indica al ingresar la presion arterial del paciente indique cual estado se encuentra
p=int(input("Escriba su presión arterial: "))
if p<90:
    print("Lastimosamente su presión arterial es baja")
elif p<120:
    print("¡QUE ALEGRIA! su presión arterial es normal")
elif p>=120 and p<=139:
    print("Lastimosamente su presión arterial se encuentra en prehipertensión")
elif p>=140 and p<=159:
    print("Lastimosamente su presión arterial se encuentra en alta:prehipertensión fase 1")
elif p>=160:
    print("Lastimosamente su presión arterial se encuentra en alta: prehipertensión fase 2")
else: print("¡Oh no! Ha ocurrido un error, ingrese nuevamente los datos")