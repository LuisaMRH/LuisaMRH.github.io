#App que al digitar la edad y diga si es MAYOR DE EDAD o MENOR DE EDAD
edad=int(input("Digite su edad: "))

if edad>=18:
    print("Usted es mayor de edad")
else:
    print("Usted es menor de edad")
