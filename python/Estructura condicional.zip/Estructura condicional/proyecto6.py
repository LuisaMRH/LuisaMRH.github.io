"""App que al ingresar el valor de compra indique que
Si el valor de la compra es mayor a $50.000,
Entonces calcule el descuento(5%) y total de la compra"""

v=int(input("Por favor ingrese el valor del producto: "))

if v>50000:
    d=v*0.05
    t=v-d
    print("Subtotal: ",v)
    print("Descuento: ",d)
    print("Total de compra: ",t)
else: 
    d=v*0.0
    t=v-d
    print("Subtotal: ",v)
    print("Descuento: ",d)
    print("Total de compra: ",t)