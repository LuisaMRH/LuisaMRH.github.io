#App para evaluar la fiebre de una persona
t=float(input("Ingrese su temperatura en °C: "))

if t>38:
    print("Con una temperatura de °C",t, " Usted tiene fiebre :(")
else:
    print("Con una temperatura de °C",t, "Usted no tiene fiebre :D")