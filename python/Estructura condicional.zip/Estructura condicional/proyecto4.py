#App para evaluar si un número está entre 10 y 100

n=int(input("Digite un numero: "))

if n>=10 & n>=100:
    print("El número ",n," se encuentra entre 10 y 100")
else:
    print("El número ",n," no se encuentra entre 10 y 100")