#App que dice si el estudiante aprobó o reprobó según su nota
n=float(input("Digite la nota del estudiante: "))

if n>=3:
    print("¡Exelente! el estudiante aprobó")
else:
    print("Lamentablemente el estuadiante reprobó")