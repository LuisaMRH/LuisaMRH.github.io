#App que al ingresar el precio de cada zapato muestre el subtotal, el descuento y el valor final de la compra
nc=int(input("Ingrese la cantidad de zapatos comprados: "))
p=int(input("Ingrese el precio de cada zapato: "))

if nc<10:
    st=p*nc
    print("El valor de su compra es de ", st, " y no recibe descuento")
elif nc>=10 and nc<20:
    st=p*nc
    t=st*0.10
    pagar=st-t
    print("Usted ha recibido un descuento del 10% que es igual a ",t, "y debe debe pegar ", pagar)
elif nc>=20 and nc<30:
    st=p*nc
    t=st*0.20
    pagar=st-t
    print("Usted ha recibido un descuento del 20% que es igual a ",t, "y debe debe pegar ", pagar)
elif nc>=30:
    st=p*nc
    t=st*0.10
    pagar=st-t
    print("Usted ha recibido un descuento del 30% que es igual a ",t, "y debe debe pegar ", pagar)
else: ("¡Oh no! Ha ocurrido un error, ingrese nuevamente los datos")