#App que indica el indice de masa corporal
p=float(input("Digite su peso en kg: "))
e=float(input("Digite su estatura en m: "))

imc=p/(e*e)
if imc<18.5:
    print("Usted se encuentra en bajo peso porque su IMC es de: ", imc)
elif imc>=18.5 and imc<=24.9:
    print("¡Excelente! usted tiene un peso normal porque su IMC es de: ", imc)
elif imc>=25 and imc<=29.9:
    print("Lamentablemente se encuentra en sobrepeso porque su IMC es de: ", imc)
elif imc>=30 and imc<=34.9:
    print("Lamentablemente se encuentra en obesidad nivel 1 porque su IMC es de: ", imc)
elif imc>=35 and imc<=39.9:
    print("Lamentablemente se encuentra en obesidad nivel 2 porque su IMC es de: ", imc)
elif imc>=40 and imc<=49.9:
    print("Lamentablemente se encuentra en obesidad nivel 3 porque su IMC es de: ", imc)
elif imc>=50:
    print("Lamentablemente se encuentra en obesidad nivel 4 porque su IMC es de: ", imc)
else: print("¡Oh no! Ha ocurrido un error, ingrese nuevamente los datos")
