#Diseñe una app que permita al usuario ingresar frutas, el precio unitario y la cantidad y lo almacene en un diccionario llamado factura. Después, debe mostrar un mensaje concatenado, donde aparece el nombre de la fruta, su valor, la cantidad y el total.
fruta=input("Ingrese el nombre de la fruta: ")
precio=(int(input("Ingrese el precio por unidad de la fruta: ")))
cantidad=(int(input("Ingrese la cantadad de fruta: ")))
total=precio*cantidad
factura={"fruta":fruta,"precio":precio,"cantidad":cantidad,"total":total}
print("-----------------------------------------------------FACTURA-----------------------------------------------------")
print("La fruta",factura["fruta"],"tiene un valor de $",factura["precio"],"pesos por unidad y usted compró",factura["cantidad"],"lo que da un total de: $",factura["total"],"pesos.")
print("-----------------------------------------------------------------------------------------------------------------")