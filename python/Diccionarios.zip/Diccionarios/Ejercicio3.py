#Diseñe una app que permita almacener la información de los clientes de una empresa. Los clientes se guardaran en un diccionario llamado clientes. Los datos deben ser ingresados por el usuario: identificación del cliente, nombre, dirección, telefono, correo y empresa. La app debe preguntar al usuario por una opción del menú. 
#1.Añadir cliente
#2.Mostrar cliente 
#3.Eliminar cliente 
#4. Salir o finalizar
cliente={}
op=""

while op !=4:  

 if op ==1:
  identificacion=input("Digite la identificación: ")
  nombre=input("Digite el nombre: ")
  direccion=input("Digite la dirección: ")
  telefono=input("Digite el numero telefonico: ")
  correo=input("Digite el correo electronico: ")
  empresa=input("Digite la empresa: ")

  cliente={
    "identificacion":identificacion,
    "nombre":nombre,
    "direccion":direccion,
    "telefono":telefono,
    "correo":correo,
    "empresa":empresa
  }

 if op ==2:
  print("Información del Cliente")
  print("---------------------------------------")
  print("identificacion: ", cliente["identificacion"])
  print("nombre: ", cliente["nombre"])                          
  print("direccion: ", cliente["direccion"])
  print("telefono: ", cliente["telefono"])
  print("correo: ", cliente["correo"])
  print("empresa: ", cliente["empresa"])

 if op ==3:
  del cliente["identificacion"]
  print("Cliente se ha eliminado con exito")

 if op ==4:
  exit()

 print("===MENU===")
 print("1 - AÑADIR CLIENTE")
 print("2 - MOSTRAR CLIENTE")
 print("3 - ELIMINAR CLIENTE")
 print("4 - SALIR")
 op=int(input("Digite la opción seleccionada: "))

