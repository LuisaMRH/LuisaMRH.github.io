#Diseñe un diccionario con la marcas de vehículos y los modelos. Debe tener un tamaño minimo de 10 elementos

vehiculos={"Chevrolet":"Onix","Suzuki":"Swift","Kia":"Picanto","Renault":"Duster","Range":"Rover","BWM":"X1","BYD":"Yuan Plus","Subaru":"WRX 2022","Jeep":"Commander","Haval":"H6"}
print("El modelo es:")
print(vehiculos["BWM"])