#Diccionario: Busqueda por clave
dict={"Sucre":"Sincelejo","Cordoba":"Monteria","Bolivar":"Cartagena","Atlantico":"Barranquilla","Cundinamarca":"Bogotá","Huila":"Neiva","Antioquia":"Medellín","Cauca":"Popayán","Córdoba":"Montería","Valle de Cauca":"Cali"}
print(dict["Bolivar"])
