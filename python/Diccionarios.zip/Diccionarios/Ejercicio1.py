#Diccionario con el método para añadir elementos
#Diseñe una app que permita al usuario Nombre, edad, dirección y telefono; estos datos se deben almacenar en un diccionario llamado persona. Estos datos se deben mostrar por patalla de forma concatenada. Ejemplo Juan tiene 17 años, vive en la Calle 8 # 27 18 A y su número de telefono es 1234567890.

nombre=input("Digite su nombre: ")
edad=input("Digite su edad: ")
direccion=input("Digite su dirección: ")
telefono=input("Digite su telefono: ")
persona={"nombre":nombre,"edad":edad,"direccion":direccion,"telefono":telefono}
print(persona["nombre"], "tiene",persona["edad"],"años,","vive en la",persona["direccion"],"y su número de telefono es",persona["telefono"])