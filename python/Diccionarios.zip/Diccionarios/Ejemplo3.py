#Diccionario de frutas
frutas={"Dulce":["Piña","Manazana","Pera","Sandia"], "Citricas":["Limón","Naranja","Pomelo","Toronja"], "Secos":["Almendra","Avellana","Pistachos","Nuez"], "Neutras":["Aguacate","Aceituna","Coco","Maní"]}
print("Frutas según su clasificación son: ")
print("------------------------------------------------")
print(frutas["Secos"])
print("------------------------------------------------")