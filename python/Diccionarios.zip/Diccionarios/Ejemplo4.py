#Diccionario de personas
#Diccionarios con diccionarios
personas={"John Peres":{"Id":110267845,"Edad":17,"Sexo":"M","Cel":3005330519,"Correo":"Jpio@gmail.com"},"Helena Torres":{"Id":110655409,"Edad":15,"Sexo":"F","Cel":3014562324,"Correo":"Hele232@gmail.com"},"Sofia Hernandez":{"Id":110456767,"Edad":21,"Sexo":"F","Cel":3559797922,"Correo":"Sohe7567@hotmail.com"},"Ana Bustamante":{"Id":110196840,"Edad":17,"Sexo":"F","Cel":3023796032,"Correo":"Anab@gmail.com"},"Andres Lopes":{"Id":102075272,"Edad":18,"Sexo":"M","Cel":3134861211,"Correo":"Andylo@gmail.com"}}
print("Datos de la persona seleccionada: ")
print(personas["Sofia Hernandez"])