#Funciones con parametros
#Función que calcula haciendo suma, resta, multiplica y divide
def calculadora(a,b):
    print("-------Calculadora--------")
    sum=a+b
    print("La suma =", sum)
    print("--------------------------")
    res=a-b
    print("La resta =", res)
    print("--------------------------")
    mul=a*b
    print("La multiplicación =", mul)
    print("--------------------------")
    div=a/b
    print("La división =", div)
    print("--------------------------")

#El usuario digita 2 números
y=int(input("Digite el primer número: "))
z=int(input("Digite el primer número: "))

calculadora(y,z) #llamar la funcion