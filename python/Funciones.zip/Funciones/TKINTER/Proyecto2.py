#Función sin parametros
#Función que suma
def suma():
    sum=a+b
    print("La suma es", sum)
#El usuario digita 2 números
a=int(input("Digite el primer número: "))
b=int(input("Digite el primer número: "))

suma() #llamar la función