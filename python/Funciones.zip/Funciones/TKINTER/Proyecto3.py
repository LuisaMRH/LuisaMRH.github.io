#Función sin parametros
#Hacer suma, resta, multiplicación y división(calculadora)

def calculadora():
    #Funciones suma, resta, multiplicación y división-------------------
    print("-------Calculadora--------")
    sum=a+b
    print("La suma =", sum)
    print("--------------------------")
    res=a-b
    print("La resta =", res)
    print("--------------------------")
    mul=a*b
    print("La multiplicación =", mul)
    print("--------------------------")
    div=a/b
    print("La división =", div)
    print("--------------------------")
#El usuario digita 2 números--------------------------------------------
a=int(input("Digite el primer número: "))
b=int(input("Digite el primer número: "))

calculadora() #llamar la funcion