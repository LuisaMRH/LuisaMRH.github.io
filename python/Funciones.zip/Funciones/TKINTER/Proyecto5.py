#Funciones con parametros
#Funcion de saludo
def saludo(name):
    print("¡Hola!",name)

#App que ingrese el nombre y lo muestre con un saludo
nombre=input("¿Cuál es tu nombre? ")
saludo(nombre) #Lamando la función