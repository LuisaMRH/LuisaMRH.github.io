#Función con parametros
#Suma
#Función de suma
def suma(a,b):
    sum=a+b
    print("la suma = ",sum)

#App que ingresa 2 enteros y los suma
x=int(input("Digite el primer número: "))
y=int(input("Digite el primer número: "))

suma(x,y) #Llamar a la función