#Función sin parametros
#3. Diseñe una app con una función que calcule el area del circulo y esta sea llamada por un algoritmo
#función que calcule el area del circulo
def circulo():
    area=(radio*radio)*3.1416
    print("El área del circulo es: ",area)
#el usuario digita el valor del radio
radio=(int(input("Digite el valor del radio: ")))
#llamar la funcion
circulo()