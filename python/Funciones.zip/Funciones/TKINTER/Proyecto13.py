#Función con parametros
#Diseña una app que calcule el area del rectangulo y luego sea llamada por un algoritmo
#función que calcule el area del rectangulo
def rectangulo(base,altura):
    area=base*altura
    print("El área del restangulo es: ",area)
#el usuario digita la base y la altura
base=int(input("Digite el valor de la base: "))
altura=int(input("Digite el valor de la altura: "))
#llamar la funcion
rectangulo(base,altura)