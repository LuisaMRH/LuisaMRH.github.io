#Función sin parametros
#def suma(Poner los parametros opcionales):

def diHola():
    print("Holi")
diHola() #Llamada la función