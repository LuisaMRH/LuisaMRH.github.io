#Función sin parametros
#Función que me convierta de horas a minutos
#Funcion que convierte------------------------------------------------------------
def convertir():
    minutos=horas*60
    print("La conversión da un resultado de: ", minutos," minutos")
#El usuario digita el número de horas que quiere convertir a minutos--------------
horas=int(input("Digite el número de horas: "))

convertir() #llamar la funcion de minutos-----------------------------------------
