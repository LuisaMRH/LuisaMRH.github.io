#Función sin parametros
#4. Diseñe una app con una función que calcule el area del cuadrado y esta sea llamada por un algoritmo
#función que calcule el area del cuadrado
def cuadrado():
    area=lado*lado
    print("El área del cuadrado es: ",area)
#el usuario digita el valor de un lado
lado=int(input("Digite el valor de un lado: "))
cuadrado()
