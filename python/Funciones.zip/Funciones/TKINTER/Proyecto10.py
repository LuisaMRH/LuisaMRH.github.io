#Función sin parametros
#2. Disena una app con una función que calcule el área del triángulo y esta sea llamada por un algoritmo
#función que calcule el area del triangulo
def triangulo():
    area=(base*altura)/2
    print("El área del triángulo es: ", area)
#el usuario digita la base y la altura
base=int(input("Digite el valor de la base: "))
altura=int(input("Digite el valor de la altura: "))
#llamar la funcion
triangulo()



