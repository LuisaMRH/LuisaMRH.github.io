#Función con parametros
#Función que me convierta de horas a minutos

def convertir(horas):
    minutos=horas*60
    print("La conversión da un resultado de --> ", minutos," minutos")
#El usuario digita el número de horas que quiere convertir a minutos
hora=int(input("Digite el número de horas: "))
convertir(hora) #llamar la funcion