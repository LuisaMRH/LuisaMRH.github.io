#while
#App que muestra la multiplicación todos los números del 1 al 100
mul=1
i=1
while i<=100:
    mul=mul*i
    print(mul)
    i=i+1