#Ciclo For: App que muestra los números del 1 al 10
#for i in range(1,11): aumentar
#for i in range(0,11,2): par
#for i in range(1,11,2): impar
#for i in range(10,0,-1): decrementar
for i in range(1,11):
    print("Los números son:", i)

