#for
#App que muestra los números pares del 1 al 100
for i in range(0,101,2):
    print(i)
