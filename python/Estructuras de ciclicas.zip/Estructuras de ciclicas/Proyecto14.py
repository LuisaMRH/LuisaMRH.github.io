#while
#App que muestra todos los números impares del 1 al 100
i=1
while i<=100:
    print(i)
    i=i+2