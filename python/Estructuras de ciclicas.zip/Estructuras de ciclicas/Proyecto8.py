#for
#App que muestra los números impares del 1 al 100
for i in range(1,101,2):
    print(i)