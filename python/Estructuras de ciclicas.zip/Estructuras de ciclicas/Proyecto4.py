#App donde al ingresa el valor inicial(i) y el final(y), muestre los datos

x=int(input("Digite el valor inicial: "))
y=int(input("Digite el valor final: "))

for i in range(x,y,1):
    print(i)