#for
#App que muestra la multiplicación de todos los números del 1 al 100
mul=1
for i in range(1,101,1):
    mul=mul*i
    print(mul)