#App que que pida al usuario una palabra y la muestre 10 veces seguidas en pantalla

p=input("Digite una palabra: ")

for i in range(10):
    print(p)