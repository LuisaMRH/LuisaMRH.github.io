#for
#App que muestra la suma de todos los números del 1 al 100
sum=0
for i in range(1,101,1):
    sum=sum+i
    print(sum)