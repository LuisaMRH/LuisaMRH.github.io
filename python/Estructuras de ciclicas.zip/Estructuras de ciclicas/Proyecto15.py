#while
#App que muestra la suma todos los números del 1 al 100
sum=0
i=1
while i<=100:
    sum=sum+i
    print(sum)
    i=i+1