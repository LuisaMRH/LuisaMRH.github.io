#App que pregunte al usuario la edad y muestre por pantalla todos los años que ha cumplido
n=int(input("Digite su edad: "))
for i in range (n):

    print("Has cumplido: ", str(i+1), "años")