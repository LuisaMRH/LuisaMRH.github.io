#for
#App que muestra los números del 100 al 1
for i in range(100,0,-1):
    print(i)