#while
#App que muestra los números del 100 al 1
i=100
while i>=1:
    print(i)
    i=i-1