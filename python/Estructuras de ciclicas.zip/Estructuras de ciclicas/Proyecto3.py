#App donde el usuario ingresa el valor inicial(i) y el final(y)

x=int(input("Digite el valor inicial: "))
y=int(input("Digite el valor final: "))

i=x
while i<=y:
    print(i)
    i+=1
else: 
    print("¡Por favor que el número inicial sea menor que el final!")